def main():
    n = eval(input("Enter number of disks: "))
    # Find the solution recursively
    print("The moves are:")
    moveDisks(n, 'A', 'B', 'C')
    # The function for finding the solution to move n disks
    # from fromTower to toTower with auxTower
global total 
total  = 0 

def moveDisks(n, fromTower, toTower, auxTower):
   global total 
   if n == 1: # Stopping condition
        
        print("Move disk", n, "from", fromTower, "to", toTower)
        total += 1 
   else:
       
       
        moveDisks(n - 1, fromTower, auxTower, toTower)
        total += 1
        print("Move disk", n, "from", fromTower, "to", toTower)
        moveDisks(n - 1, auxTower, toTower, fromTower)
        
        print("Your total numbers of moves are  " +  str(total))
main() # Call the main function